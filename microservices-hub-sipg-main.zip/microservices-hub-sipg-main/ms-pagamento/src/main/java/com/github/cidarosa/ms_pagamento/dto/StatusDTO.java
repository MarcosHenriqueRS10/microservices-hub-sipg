package com.github.cidarosa.ms_pagamento.dto;

import com.github.cidarosa.ms_pagamento.entity.Status;
import lombok.Getter;

@Getter
public class StatusDTO {

    private Status status;
}
